package com.infosys.repository;

import java.util.HashMap;
import java.util.Map;

import com.infosys.domain.Employee;


/**
 * The Class EmployeeRepositoryImpl.
 */
public class EmployeeRepositoryImpl implements EmployeeRepository {
	
	/** The count. */
	private static int count = 1;
	
	/** The employee map. */
	private static Map<Integer, Employee> employeeMap = new HashMap<Integer, Employee>();

	/* 
	 * method to retrieve employee details based on employee id
	 */
	public Employee getEmployeeDetails(int id) {

		Employee employee = employeeMap.get(id);
		return employee;
	}

	/* 
	 * method to insert employee details
	 */
	public void save(Employee emp) {
		emp.setEmpId(count++);
		employeeMap.put(emp.getEmpId(), emp);

	}

}
