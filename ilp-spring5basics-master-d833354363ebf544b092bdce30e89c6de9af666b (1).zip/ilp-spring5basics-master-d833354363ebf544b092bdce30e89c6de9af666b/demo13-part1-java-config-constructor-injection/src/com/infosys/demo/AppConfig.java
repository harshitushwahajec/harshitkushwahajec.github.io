package com.infosys.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean
	public ReportGenerator htmlReportGenerator(){
		return new HTMLReportGenerator();
		
	}
	
	@Bean
	public ReportGenerator pdfReportGenerator(){
		return new PDFReportGenerator();
		
	}
	
	@Bean
	public ReportService reportService(){
		ReportService reportService=new ReportService(pdfReportGenerator(),100);
		return  reportService;
		
	}


}
