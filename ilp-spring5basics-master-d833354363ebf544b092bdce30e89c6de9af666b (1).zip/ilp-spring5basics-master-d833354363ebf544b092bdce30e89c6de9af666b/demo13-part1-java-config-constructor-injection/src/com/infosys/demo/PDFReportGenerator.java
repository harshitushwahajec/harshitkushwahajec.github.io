package com.infosys.demo;

import java.util.List;
import java.util.Map;

public class PDFReportGenerator implements ReportGenerator {
	List lstValues;
	Map mapDetails;

	@Override
	public String generateReport(int recordsPerPage) {
		if (lstValues != null)
			lstValues.forEach(v -> System.out.println(v));
		if (mapDetails != null)
			mapDetails.forEach((k, v) -> System.out.println(k + ":" + v));

		return "Generated PDF Report with " + recordsPerPage + " records";
	}

	public List getLstValues() {
		return lstValues;
	}

	public void setLstValues(List lstValues) {
		this.lstValues = lstValues;
	}

	public Map getMapDetails() {
		return mapDetails;
	}

	public void setMapDetails(Map mapDetails) {
		this.mapDetails = mapDetails;
	}

}
