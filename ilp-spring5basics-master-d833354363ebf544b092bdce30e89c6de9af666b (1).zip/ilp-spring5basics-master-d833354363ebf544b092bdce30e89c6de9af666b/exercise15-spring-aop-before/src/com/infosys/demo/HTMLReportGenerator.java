package com.infosys.demo;

import org.springframework.stereotype.Component;

@Component("htmlGenerator")
public class HTMLReportGenerator implements ReportGenerator {
	@Override
	public String generateReport(int recordsPerPage) {
		
		return "Generated HTML Report  with " + recordsPerPage + " records";
	}

	/*public String generateReport(int recordsPerPage) {

		String ret = "Generated HTML Report  with " + recordsPerPage + " records";
		System.out.println("Going to return");
		return ret;
	}
*/
//	public String generateReport(int recordsPerPage) throws Exception{
//		System.out.println("In HTMLReportGenerator generate");
//
//		String ret = "Generated HTML Report  with " + recordsPerPage + " records";
//		//throw new Exception("error in report");
//		return ret;
//	}
}