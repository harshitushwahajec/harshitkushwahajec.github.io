package com.infosys.demo;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class ReportAspect {
	
	@Before("execution(String com.infosys.demo.ReportGenerator.generateReport(int))")
	public void beforeAdvice(){
		System.out.println("Before Advice");
	}
	
	
	
	
}
