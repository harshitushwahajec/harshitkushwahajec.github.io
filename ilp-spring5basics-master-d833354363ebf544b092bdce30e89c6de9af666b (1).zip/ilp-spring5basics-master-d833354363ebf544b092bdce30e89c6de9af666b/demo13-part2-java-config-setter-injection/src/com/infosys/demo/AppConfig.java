package com.infosys.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean
	public ReportGenerator htmlGenerator(){
		return new HTMLReportGenerator();
		
	}
	
	@Bean
	public ReportGenerator pdfGenerator(){
		return new PDFReportGenerator();
		
	}
	
	@Bean
	public ReportService reportService(){
		ReportService reportService=new ReportService();
		reportService.setMaster(htmlGenerator());
		return reportService;
		
	}


}
