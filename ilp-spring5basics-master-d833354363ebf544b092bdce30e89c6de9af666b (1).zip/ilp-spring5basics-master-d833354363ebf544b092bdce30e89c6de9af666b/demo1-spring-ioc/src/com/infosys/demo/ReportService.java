package com.infosys.demo;

public class ReportService {

	public void display() {
		System.out.println("Hi, Welcome to Report Generation application");
	}
}
