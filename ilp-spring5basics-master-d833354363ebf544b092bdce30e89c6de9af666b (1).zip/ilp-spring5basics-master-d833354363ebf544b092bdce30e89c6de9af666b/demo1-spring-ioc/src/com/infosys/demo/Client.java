package com.infosys.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * The Class EmployeeClient.
 */
public class Client{

	
	private static ApplicationContext context;

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */
	public static void main(String[] args) {
		
		context = new ClassPathXmlApplicationContext("config.xml");
		ReportService reportService = (ReportService) context.getBean("reportService");
		reportService.display();
	}

}
